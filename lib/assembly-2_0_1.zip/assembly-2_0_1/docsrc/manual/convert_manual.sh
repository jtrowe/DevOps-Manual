#!/bin/sh

###
### Please edit the 3 following variables to reflect where:
###
### * The DocBook XSL stylesheets v1.79.1 for DocBook v5+ (i.e. with namespace)
###   https://sourceforge.net/projects/docbook/
###
### * Saxon 6.5.5
###   http://saxon.sourceforge.net/saxon6.5.5/index.html
###
### * Apache FOP 1.1, 2.0 or 2.1
###   https://xmlgraphics.apache.org/fop/download.html
###
### have been installed.
###

DOCBOOK_XSL=/usr/local/src/docbook-xsl-ns-1.79.1

SAXON="java -cp /usr/local/src/saxon6-5-5/saxon.jar com.icl.saxon.StyleSheet"

FOP=/opt/fop/fop

### ---

rm -rf ../../doc/manual/*
cp -r images ../../doc/manual

### ---

echo "Generating HTML..."

../../bin/assembly -check -v -format web manual.xml out/manual_realized_web.xml

$SAXON -o ../../doc/manual/index.html out/manual_realized_web.xml \
    "$DOCBOOK_XSL/html/chunk.xsl" \
    base.dir=../../doc/manual/ \
    chunk.section.depth=0 \
    section.autolabel=1 \
    section.label.includes.component.label=1 \
    use.id.as.filename=1 \
    html.stylesheet=html.css \
    callout.graphics=0

cp html.css ../../doc/manual/

### ---

echo "Generating PDF..."

../../bin/assembly -check -v manual.xml out/manual_realized.xml

$SAXON -o out/manual_realized.fo out/manual_realized.xml \
    "$DOCBOOK_XSL/fo/docbook.xsl" \
    paper.type=A4 \
    section.autolabel=1 \
    section.label.includes.component.label=1 \
    variablelist.as.blocks=1 \
    ulink.show=0 \
    callout.graphics=0 \
    shade.verbatim=1

$FOP -fo out/manual_realized.fo -pdf ../../doc/manual/manual.pdf
