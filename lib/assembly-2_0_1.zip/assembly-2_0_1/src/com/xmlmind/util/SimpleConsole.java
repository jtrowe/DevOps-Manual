/*
 * Copyright (c) 2017-2021 XMLmind Software. All rights reserved. 
 *
 * Author: Hussein Shafie
 *
 * This file is part of several XMLmind projects.
 * For conditions of distribution and use, see the accompanying legal.txt file.
 */
package com.xmlmind.util;

import java.io.PrintStream;
import com.xmlmind.util.Console;

/**
 * An implementation of Console which prints its messages to
 * {@link java.lang.System#err} and {@link java.lang.System#out}.
 */
public final class SimpleConsole implements Console {
    /**
     * A ready-to-use instance of <code>SimpleConsole</code>
     */
    public static final SimpleConsole INSTANCE = new SimpleConsole();
    
    private String prefix;
    private boolean showMessageType;
    private MessageType errorLevel;

    // -----------------------------------------------------------------------

    /**
     * Equivalent to {@link #SimpleConsole(String, boolean, Console.MessageType)
     * this(null, true, MessageType.INFO)}.
     */
    public SimpleConsole() {
        this(null, true, MessageType.INFO);
    }

    /**
     * Constructs a <code>SimpleConsole</code>.
     *
     * @param prefix prefix to be added to the messages displayed 
     * by this console; may be <code>null</code>
     * @param showMessageType specifies whether the type of the message 
     * should be used to prefix the messages displayed by this console
     * @param errorLevel specifies the least severe message type 
     * displayed by this console
     */
    public SimpleConsole(String prefix, boolean showMessageType,
                         MessageType errorLevel) {
        this.prefix = prefix;
        this.showMessageType = showMessageType;
        this.errorLevel = errorLevel;
    }

    /**
     * Specifies the prefix to be added to the messages displayed 
     * by this console; may be <code>null</code>.
     */
    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    /**
     * Returns the prefix to be added to the messages displayed 
     * by this console; may return <code>null</code>.
     */
    public String getPrefix() {
        return prefix;
    }

    /**
     * Specifies whether the type of the message should be used 
     * to prefix the messages displayed by this console.
     */
    public void setShowingMessageType(boolean show) {
        showMessageType = show;
    }

    /**
     * Returns <code>true</code> if the type of the message should be used 
     * to prefix the messages displayed by this console;
     * <code>false</code> otherwise.
     */
    public boolean isShowingMessageType() {
        return showMessageType;
    }

    /**
     * Specifies the least severe message type displayed by this console.
     */
    public void setErrorLevel(MessageType level) {
       errorLevel = level;
    }

    /**
     * Returns the least severe message type displayed by this console.
     */
    public MessageType getErrorLevel() {
        return errorLevel;
    }

    public void showMessage(String message, MessageType messageType) {
        PrintStream output;
        if (messageType.ordinal() >= errorLevel.ordinal()) {
            output = System.out;
        } else {
            output = System.err;
        }
        if (prefix != null) {
            output.print(prefix);
        } 
        if (showMessageType) {
            output.print(messageType);
            output.print(": ");
        }
        output.println(message);
    }
}
