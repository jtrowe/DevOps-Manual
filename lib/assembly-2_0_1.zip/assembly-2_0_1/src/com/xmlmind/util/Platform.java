/*
 * Copyright (c) 2017 XMLmind Software. 
 *
 * Author: Hussein Shafie
 *
 * This file is part of several XMLmind projects.
 * For conditions of distribution and use, see the accompanying legal.txt file.
 */
package com.xmlmind.util;

/**
 * All the possible platforms.
 */
public enum Platform {
    /**
     * Any flavor of Microsoft Windows.
     */
    WINDOWS,

    /**
     * Mac OS X.
     */
    MAC_OS,

    /**
     * Any Unix other than Mac OS X (Linux, Solaris, etc).
     */
    GENERIC_UNIX
}
