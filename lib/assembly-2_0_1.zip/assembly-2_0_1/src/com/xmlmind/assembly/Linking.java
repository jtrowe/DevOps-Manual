/*
 * Copyright (c) 2017 XMLmind Software. All rights reserved.
 *
 * Author: Hussein Shafie
 *
 * This file is part of the XMLmind Assembly Processor project.
 * For conditions of distribution and use, see the accompanying legal.txt file.
 */
package com.xmlmind.assembly;

/**
 * <b>Not part of the public, documented, API:</b> representation of attribute
 * <code>&lt;instance&gt;/@linking</code>.
 */
public enum Linking {
    TARGET_ONLY,
    SOURCE_ONLY,
    NORMAL,
    NONE;

    public static Linking fromString(String spec) {
        if ("targetonly".equals(spec)) {
            return TARGET_ONLY;
        } else if ("sourceonly".equals(spec)) {
            return SOURCE_ONLY;
        } else if ("normal".equals(spec)) {
            return NORMAL;
        } else if ("none".equals(spec)) {
            return NONE;
        } else {
            return null;
        }
    }

    @Override
    public String toString() {
        switch (this) {
        case TARGET_ONLY:
            return "targetonly";
        case SOURCE_ONLY:
            return "sourceonly";
        case NORMAL:
            return "normal";
        case NONE:
            return "none";
        default:
            return "???";
        }
    }
}

