/*
 * Copyright (c) 2017 XMLmind Software. All rights reserved.
 *
 * Author: Hussein Shafie
 *
 * This file is part of the XMLmind Assembly Processor project.
 * For conditions of distribution and use, see the accompanying legal.txt file.
 */
package com.xmlmind.assembly;

import com.xmlmind.util.Localizer;

/*package*/ final class Msg {
    private static Localizer localizer = new Localizer(Msg.class);

    public static String msg(String id) {
        return localizer.msg(id);
    }

    public static String msg(String id, Object... args) {
        return localizer.msg(id, args);
    }
}
