/*
 * Copyright (c) 2017 XMLmind Software. All rights reserved.
 *
 * Author: Hussein Shafie
 *
 * This file is part of the XMLmind Assembly Processor project.
 * For conditions of distribution and use, see the accompanying legal.txt file.
 */
package com.xmlmind.assembly;

/**
 * <b>Not part of the public, documented, API:</b> representation of element
 * <code>&lt;instance&gt;</code>.
 */
@SuppressWarnings("overrides")
public final class Instance {
    public Linking linking; // May be null; means: normal.
    public String resourceId;
    public String realizedId; // Initially null.

    public static final Instance[] EMPTY_LIST = new Instance[0];

    // -----------------------------------------------------------------------

    public Instance(Linking linking, String resourceId) {
        this.linking = linking;
        this.resourceId = resourceId;
    }

    public Linking getLinking() {
        return (linking == null)? Linking.NORMAL : linking;
    }

    @Override
    public boolean equals(Object other) {
        if (other == null || !(other instanceof Instance)) {
            return false;
        }

        Instance o = (Instance) other;
        return (linking == o.linking && resourceId.equals(o.resourceId));
    }
}



