/*
 * Copyright (c) 2017 XMLmind Software. All rights reserved.
 *
 * Author: Hussein Shafie
 *
 * This file is part of the XMLmind Assembly Processor project.
 * For conditions of distribution and use, see the accompanying legal.txt file.
 */
package com.xmlmind.assembly;

import javax.xml.transform.ErrorListener;
import javax.xml.transform.TransformerException;
import com.xmlmind.util.Console;

/*package*/ final class ConsoleErrorListener implements ErrorListener {
    public final Console console;

    // -----------------------------------------------------------------------

    public ConsoleErrorListener(Console console) {
        this.console = console;
    }

    public void warning(TransformerException e) 
        throws TransformerException {
        if (console != null) {
            console.showMessage(Msg.msg("transformWarning",
                                        e.getMessageAndLocation()),
                                Console.MessageType.WARNING);
        }
    }

    public void error(TransformerException e) 
        throws TransformerException {
        if (console != null) {
            console.showMessage(Msg.msg("transformError",
                                        e.getMessageAndLocation()),
                                Console.MessageType.ERROR);
        }
    }

    public void fatalError(TransformerException e) 
        throws TransformerException {
        if (console != null) {
            console.showMessage(Msg.msg("transformFatalError",
                                        e.getMessageAndLocation()),
                                Console.MessageType.ERROR);
        }

        // Just in case.
        throw e;
    }
}
