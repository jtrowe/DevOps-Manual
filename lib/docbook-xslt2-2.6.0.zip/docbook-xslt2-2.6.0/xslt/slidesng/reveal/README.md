# reveal.js stylesheets for DocBook slides

This is a crude attempt to generate nice slideshow powered by [reveal.js](http://lab.hakim.se/reveal-js) library.

Input must be DocBook Slides as defined in https://sourceforge.net/p/docbook/code/HEAD/tree/trunk/xsl/slides/

Transformation expect that [reveal.js](http://lab.hakim.se/reveal-js) resources are available at location specified by $reveal.uri parameter. By default this `reveal` subdirectory, but you can point to another location, for example to copy of reveal.js hosted on CDN.


